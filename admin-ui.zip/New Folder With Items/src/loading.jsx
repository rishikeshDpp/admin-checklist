import React from 'react'

const PlaceHolderTable = () => {
  return (
    <div className='text-white '>loading</div>
  )
}

export default PlaceHolderTable
